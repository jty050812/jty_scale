.obj/source/library/string/strspn.o: source/library/string/strspn.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
