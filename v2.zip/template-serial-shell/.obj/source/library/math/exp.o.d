.obj/source/library/math/exp.o: source/library/math/exp.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
