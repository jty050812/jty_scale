.obj/source/library/stdio/vsscanf.o: source/library/stdio/vsscanf.c \
 include/library/stdio.h include/library/types.h include/library/ctype.h \
 include/library/errno.h include/library/stdarg.h \
 include/library/stddef.h include/library/stdlib.h \
 include/library/limits.h include/library/string.h
include/library/stdio.h:
include/library/types.h:
include/library/ctype.h:
include/library/errno.h:
include/library/stdarg.h:
include/library/stddef.h:
include/library/stdlib.h:
include/library/limits.h:
include/library/string.h:
