.obj/source/hardware/s5pv210-serial.o: source/hardware/s5pv210-serial.c \
 include/library/types.h include/library/string.h include/library/io.h \
 include/library/stddef.h include/hardware/s5pv210/reg-gpio.h \
 include/hardware/s5pv210/reg-serial.h include/hardware/s5pv210-clk.h \
 include/hardware/s5pv210-serial.h
include/library/types.h:
include/library/string.h:
include/library/io.h:
include/library/stddef.h:
include/hardware/s5pv210/reg-gpio.h:
include/hardware/s5pv210/reg-serial.h:
include/hardware/s5pv210-clk.h:
include/hardware/s5pv210-serial.h:
