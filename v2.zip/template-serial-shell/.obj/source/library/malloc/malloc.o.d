.obj/source/library/malloc/malloc.o: source/library/malloc/malloc.c \
 include/library/sizes.h include/library/malloc.h include/library/types.h \
 include/library/stddef.h include/library/assert.h \
 include/library/string.h
include/library/sizes.h:
include/library/malloc.h:
include/library/types.h:
include/library/stddef.h:
include/library/assert.h:
include/library/string.h:
