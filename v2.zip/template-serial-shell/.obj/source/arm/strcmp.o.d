.obj/source/arm/strcmp.o: source/arm/strcmp.S
