.obj/source/library/string/strsep.o: source/library/string/strsep.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
