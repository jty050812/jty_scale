.obj/source/library/math/modff.o: source/library/math/modff.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
