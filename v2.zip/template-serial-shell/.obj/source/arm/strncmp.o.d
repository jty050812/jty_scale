.obj/source/arm/strncmp.o: source/arm/strncmp.S
