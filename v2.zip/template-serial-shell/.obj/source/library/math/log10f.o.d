.obj/source/library/math/log10f.o: source/library/math/log10f.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
