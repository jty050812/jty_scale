.obj/source/hardware/hx711.o: source/hardware/hx711.c \
 include/hardware/hx711.h include/library/types.h include/library/io.h \
 include/hardware/s5pv210/reg-gpio.h \
 include/hardware/s5pv210-tick-delay.h
include/hardware/hx711.h:
include/library/types.h:
include/library/io.h:
include/hardware/s5pv210/reg-gpio.h:
include/hardware/s5pv210-tick-delay.h:
