.obj/source/library/stdlib/bsearch.o: source/library/stdlib/bsearch.c \
 include/library/types.h include/library/stddef.h \
 include/library/stdlib.h
include/library/types.h:
include/library/stddef.h:
include/library/stdlib.h:
