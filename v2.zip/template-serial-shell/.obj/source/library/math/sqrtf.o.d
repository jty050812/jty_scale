.obj/source/library/math/sqrtf.o: source/library/math/sqrtf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
