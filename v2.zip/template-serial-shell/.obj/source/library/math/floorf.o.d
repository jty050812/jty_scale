.obj/source/library/math/floorf.o: source/library/math/floorf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
