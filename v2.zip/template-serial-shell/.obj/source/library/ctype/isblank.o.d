.obj/source/library/ctype/isblank.o: source/library/ctype/isblank.c \
 include/library/ctype.h
include/library/ctype.h:
