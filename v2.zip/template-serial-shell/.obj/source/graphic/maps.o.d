.obj/source/graphic/maps.o: source/graphic/maps.c include/library/types.h \
 include/library/stddef.h include/graphic/maps.h include/graphic/rect.h \
 include/graphic/maps/software.h include/graphic/surface.h \
 include/library/malloc.h include/library/assert.h \
 include/library/sizes.h include/library/string.h include/graphic/pixel.h \
 include/graphic/color.h
include/library/types.h:
include/library/stddef.h:
include/graphic/maps.h:
include/graphic/rect.h:
include/graphic/maps/software.h:
include/graphic/surface.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/string.h:
include/graphic/pixel.h:
include/graphic/color.h:
