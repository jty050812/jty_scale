.obj/source/hardware/s5pv210-irq.o: source/hardware/s5pv210-irq.c \
 include/library/types.h include/library/stddef.h include/library/io.h \
 include/library/sizes.h include/library/string.h \
 include/hardware/s5pv210/reg-gpio.h include/hardware/s5pv210/reg-vic.h \
 include/hardware/s5pv210-cp15.h include/hardware/s5pv210-irq.h
include/library/types.h:
include/library/stddef.h:
include/library/io.h:
include/library/sizes.h:
include/library/string.h:
include/hardware/s5pv210/reg-gpio.h:
include/hardware/s5pv210/reg-vic.h:
include/hardware/s5pv210-cp15.h:
include/hardware/s5pv210-irq.h:
