.obj/source/library/math/atan2.o: source/library/math/atan2.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
