.obj/source/library/ctype/islower.o: source/library/ctype/islower.c \
 include/library/ctype.h
include/library/ctype.h:
