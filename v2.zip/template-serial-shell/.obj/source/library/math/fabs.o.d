.obj/source/library/math/fabs.o: source/library/math/fabs.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
