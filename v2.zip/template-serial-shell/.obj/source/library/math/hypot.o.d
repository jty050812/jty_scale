.obj/source/library/math/hypot.o: source/library/math/hypot.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
