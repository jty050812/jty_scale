.obj/source/library/string/strcmp.o: source/library/string/strcmp.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
