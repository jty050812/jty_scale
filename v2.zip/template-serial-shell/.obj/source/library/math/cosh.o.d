.obj/source/library/math/cosh.o: source/library/math/cosh.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
