.obj/source/library/math/k_sinf.o: source/library/math/k_sinf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
