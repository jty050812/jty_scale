.obj/source/library/exit/abort.o: source/library/exit/abort.c \
 include/library/exit.h
include/library/exit.h:
