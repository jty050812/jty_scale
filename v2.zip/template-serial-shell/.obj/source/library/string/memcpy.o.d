.obj/source/library/string/memcpy.o: source/library/string/memcpy.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
