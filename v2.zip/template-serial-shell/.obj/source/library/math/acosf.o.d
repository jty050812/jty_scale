.obj/source/library/math/acosf.o: source/library/math/acosf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
