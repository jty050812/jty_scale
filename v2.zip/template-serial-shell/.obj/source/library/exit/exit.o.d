.obj/source/library/exit/exit.o: source/library/exit/exit.c \
 include/library/exit.h
include/library/exit.h:
