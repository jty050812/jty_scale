.obj/source/graphic/rect.o: source/graphic/rect.c \
 include/library/stddef.h include/graphic/rect.h include/library/types.h
include/library/stddef.h:
include/graphic/rect.h:
include/library/types.h:
