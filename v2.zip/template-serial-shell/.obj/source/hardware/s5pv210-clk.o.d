.obj/source/hardware/s5pv210-clk.o: source/hardware/s5pv210-clk.c \
 include/library/types.h include/library/stddef.h include/library/io.h \
 include/library/string.h include/library/sizes.h \
 include/hardware/s5pv210/reg-clk.h include/hardware/s5pv210-clk.h
include/library/types.h:
include/library/stddef.h:
include/library/io.h:
include/library/string.h:
include/library/sizes.h:
include/hardware/s5pv210/reg-clk.h:
include/hardware/s5pv210-clk.h:
