.obj/source/library/math/copysignf.o: source/library/math/copysignf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
