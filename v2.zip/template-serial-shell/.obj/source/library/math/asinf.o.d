.obj/source/library/math/asinf.o: source/library/math/asinf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
