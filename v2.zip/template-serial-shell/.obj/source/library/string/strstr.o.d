.obj/source/library/string/strstr.o: source/library/string/strstr.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
