.obj/source/library/math/cos.o: source/library/math/cos.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
