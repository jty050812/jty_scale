.obj/source/library/math/modf.o: source/library/math/modf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
