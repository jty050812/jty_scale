.obj/source/library/string/memset.o: source/library/string/memset.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
