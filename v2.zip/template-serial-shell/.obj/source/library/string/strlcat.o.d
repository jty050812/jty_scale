.obj/source/library/string/strlcat.o: source/library/string/strlcat.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
