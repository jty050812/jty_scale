.obj/source/library/string/strnchr.o: source/library/string/strnchr.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
