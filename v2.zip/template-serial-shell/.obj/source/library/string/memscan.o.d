.obj/source/library/string/memscan.o: source/library/string/memscan.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
