.obj/source/library/stdlib/labs.o: source/library/stdlib/labs.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
