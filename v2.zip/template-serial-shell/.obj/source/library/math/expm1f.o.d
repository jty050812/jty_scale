.obj/source/library/math/expm1f.o: source/library/math/expm1f.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
