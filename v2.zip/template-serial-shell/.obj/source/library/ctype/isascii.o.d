.obj/source/library/ctype/isascii.o: source/library/ctype/isascii.c \
 include/library/ctype.h
include/library/ctype.h:
