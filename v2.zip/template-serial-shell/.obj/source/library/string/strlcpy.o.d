.obj/source/library/string/strlcpy.o: source/library/string/strlcpy.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
