.obj/source/library/math/frexp.o: source/library/math/frexp.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
