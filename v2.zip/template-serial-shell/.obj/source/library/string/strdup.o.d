.obj/source/library/string/strdup.o: source/library/string/strdup.c \
 include/library/types.h include/library/stddef.h \
 include/library/malloc.h include/library/assert.h \
 include/library/sizes.h include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/string.h:
