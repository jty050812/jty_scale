.obj/source/arm/memmove.o: source/arm/memmove.S
