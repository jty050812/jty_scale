.obj/source/arm/memcmp.o: source/arm/memcmp.S
