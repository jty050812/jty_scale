.obj/source/library/stdlib/strtoll.o: source/library/stdlib/strtoll.c \
 include/library/ctype.h include/library/errno.h include/library/limits.h \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/ctype.h:
include/library/errno.h:
include/library/limits.h:
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
