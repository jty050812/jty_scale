.obj/source/library/math/fmodf.o: source/library/math/fmodf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
