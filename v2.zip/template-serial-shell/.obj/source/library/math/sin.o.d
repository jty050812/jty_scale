.obj/source/library/math/sin.o: source/library/math/sin.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
