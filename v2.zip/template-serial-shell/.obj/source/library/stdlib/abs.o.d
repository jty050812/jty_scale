.obj/source/library/stdlib/abs.o: source/library/stdlib/abs.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
