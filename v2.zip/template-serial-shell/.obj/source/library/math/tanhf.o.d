.obj/source/library/math/tanhf.o: source/library/math/tanhf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
