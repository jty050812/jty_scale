.obj/source/library/math/acos.o: source/library/math/acos.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
