.obj/source/library/math/copysign.o: source/library/math/copysign.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
