.obj/source/library/math/pow.o: source/library/math/pow.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
