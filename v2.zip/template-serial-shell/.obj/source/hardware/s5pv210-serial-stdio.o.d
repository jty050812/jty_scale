.obj/source/hardware/s5pv210-serial-stdio.o: \
 source/hardware/s5pv210-serial-stdio.c include/library/malloc.h \
 include/library/types.h include/library/stddef.h \
 include/library/assert.h include/library/sizes.h \
 include/library/string.h include/library/stdio.h include/library/ctype.h \
 include/library/errno.h include/library/stdarg.h \
 include/library/stdlib.h include/library/limits.h \
 include/hardware/s5pv210-serial.h \
 include/hardware/s5pv210-serial-stdio.h
include/library/malloc.h:
include/library/types.h:
include/library/stddef.h:
include/library/assert.h:
include/library/sizes.h:
include/library/string.h:
include/library/stdio.h:
include/library/ctype.h:
include/library/errno.h:
include/library/stdarg.h:
include/library/stdlib.h:
include/library/limits.h:
include/hardware/s5pv210-serial.h:
include/hardware/s5pv210-serial-stdio.h:
