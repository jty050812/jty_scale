.obj/source/library/math/tanh.o: source/library/math/tanh.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
