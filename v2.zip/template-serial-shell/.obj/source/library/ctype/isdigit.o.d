.obj/source/library/ctype/isdigit.o: source/library/ctype/isdigit.c \
 include/library/ctype.h
include/library/ctype.h:
