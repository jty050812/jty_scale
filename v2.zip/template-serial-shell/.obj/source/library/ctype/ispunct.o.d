.obj/source/library/ctype/ispunct.o: source/library/ctype/ispunct.c \
 include/library/ctype.h
include/library/ctype.h:
