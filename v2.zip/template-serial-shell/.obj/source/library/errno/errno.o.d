.obj/source/library/errno/errno.o: source/library/errno/errno.c \
 include/library/errno.h
include/library/errno.h:
