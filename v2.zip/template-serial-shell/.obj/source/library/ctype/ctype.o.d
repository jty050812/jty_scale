.obj/source/library/ctype/ctype.o: source/library/ctype/ctype.c \
 include/library/ctype.h
include/library/ctype.h:
