.obj/source/graphic/text.o: source/graphic/text.c include/graphic/text.h \
 include/library/types.h include/graphic/surface.h \
 include/library/stddef.h include/library/malloc.h \
 include/library/assert.h include/library/sizes.h \
 include/library/string.h include/graphic/pixel.h include/graphic/color.h \
 include/graphic/maps.h include/graphic/rect.h \
 include/graphic/maps/software.h include/library/stdio.h \
 include/library/ctype.h include/library/errno.h include/library/stdarg.h \
 include/library/stdlib.h include/library/limits.h
include/graphic/text.h:
include/library/types.h:
include/graphic/surface.h:
include/library/stddef.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/string.h:
include/graphic/pixel.h:
include/graphic/color.h:
include/graphic/maps.h:
include/graphic/rect.h:
include/graphic/maps/software.h:
include/library/stdio.h:
include/library/ctype.h:
include/library/errno.h:
include/library/stdarg.h:
include/library/stdlib.h:
include/library/limits.h:
