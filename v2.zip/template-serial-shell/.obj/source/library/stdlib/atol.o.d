.obj/source/library/stdlib/atol.o: source/library/stdlib/atol.c \
 include/library/stddef.h include/library/stdlib.h \
 include/library/types.h
include/library/stddef.h:
include/library/stdlib.h:
include/library/types.h:
