.obj/source/library/math/cosf.o: source/library/math/cosf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
