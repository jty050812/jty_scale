.obj/source/library/readline.o: source/library/readline.c \
 include/library/types.h include/library/string.h include/library/stdio.h \
 include/library/ctype.h include/library/errno.h include/library/stdarg.h \
 include/library/stddef.h include/library/stdlib.h \
 include/library/limits.h include/library/malloc.h \
 include/library/assert.h include/library/sizes.h \
 include/library/charset.h include/hardware/s5pv210-serial.h \
 include/library/readline.h
include/library/types.h:
include/library/string.h:
include/library/stdio.h:
include/library/ctype.h:
include/library/errno.h:
include/library/stdarg.h:
include/library/stddef.h:
include/library/stdlib.h:
include/library/limits.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/charset.h:
include/hardware/s5pv210-serial.h:
include/library/readline.h:
