.obj/source/library/string/strnicmp.o: source/library/string/strnicmp.c \
 include/library/types.h include/library/ctype.h include/library/string.h
include/library/types.h:
include/library/ctype.h:
include/library/string.h:
