.obj/source/library/ctype/toupper.o: source/library/ctype/toupper.c \
 include/library/ctype.h
include/library/ctype.h:
