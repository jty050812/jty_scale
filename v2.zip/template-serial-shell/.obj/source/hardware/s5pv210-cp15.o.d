.obj/source/hardware/s5pv210-cp15.o: source/hardware/s5pv210-cp15.c \
 include/library/types.h include/hardware/s5pv210-cp15.h
include/library/types.h:
include/hardware/s5pv210-cp15.h:
