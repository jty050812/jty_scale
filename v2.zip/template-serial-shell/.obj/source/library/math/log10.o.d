.obj/source/library/math/log10.o: source/library/math/log10.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
