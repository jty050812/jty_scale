.obj/source/library/string/strchr.o: source/library/string/strchr.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
