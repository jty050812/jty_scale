.obj/source/library/ctype/isgraph.o: source/library/ctype/isgraph.c \
 include/library/ctype.h
include/library/ctype.h:
