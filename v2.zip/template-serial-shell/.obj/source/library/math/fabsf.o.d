.obj/source/library/math/fabsf.o: source/library/math/fabsf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
