.obj/source/library/math/k_cos.o: source/library/math/k_cos.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
