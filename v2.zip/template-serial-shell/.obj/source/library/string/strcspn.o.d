.obj/source/library/string/strcspn.o: source/library/string/strcspn.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
