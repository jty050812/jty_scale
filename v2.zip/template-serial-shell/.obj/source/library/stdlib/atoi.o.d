.obj/source/library/stdlib/atoi.o: source/library/stdlib/atoi.c \
 include/library/stddef.h include/library/stdlib.h \
 include/library/types.h
include/library/stddef.h:
include/library/stdlib.h:
include/library/types.h:
