.obj/source/library/math/frexpf.o: source/library/math/frexpf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
