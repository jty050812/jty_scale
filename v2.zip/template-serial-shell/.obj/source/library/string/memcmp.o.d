.obj/source/library/string/memcmp.o: source/library/string/memcmp.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
