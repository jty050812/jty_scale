.obj/source/library/math/ceilf.o: source/library/math/ceilf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
