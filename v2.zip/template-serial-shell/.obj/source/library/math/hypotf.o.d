.obj/source/library/math/hypotf.o: source/library/math/hypotf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
