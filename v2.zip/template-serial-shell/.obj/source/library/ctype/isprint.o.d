.obj/source/library/ctype/isprint.o: source/library/ctype/isprint.c \
 include/library/ctype.h
include/library/ctype.h:
