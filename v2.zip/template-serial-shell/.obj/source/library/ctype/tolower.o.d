.obj/source/library/ctype/tolower.o: source/library/ctype/tolower.c \
 include/library/ctype.h
include/library/ctype.h:
