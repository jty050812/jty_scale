.obj/source/library/math/k_tanf.o: source/library/math/k_tanf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
