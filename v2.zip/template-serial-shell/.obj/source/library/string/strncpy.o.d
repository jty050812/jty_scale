.obj/source/library/string/strncpy.o: source/library/string/strncpy.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
