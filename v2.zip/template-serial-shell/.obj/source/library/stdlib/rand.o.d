.obj/source/library/stdlib/rand.o: source/library/stdlib/rand.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
