.obj/source/startup/start.o: source/startup/start.S
