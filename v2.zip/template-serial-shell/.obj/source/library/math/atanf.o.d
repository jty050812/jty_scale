.obj/source/library/math/atanf.o: source/library/math/atanf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
