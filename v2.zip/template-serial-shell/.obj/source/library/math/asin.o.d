.obj/source/library/math/asin.o: source/library/math/asin.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
