.obj/source/library/string/strrchr.o: source/library/string/strrchr.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
