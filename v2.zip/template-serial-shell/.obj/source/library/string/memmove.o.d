.obj/source/library/string/memmove.o: source/library/string/memmove.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
