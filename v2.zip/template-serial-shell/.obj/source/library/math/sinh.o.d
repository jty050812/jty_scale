.obj/source/library/math/sinh.o: source/library/math/sinh.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
