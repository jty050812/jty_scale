.obj/source/library/math/atan2f.o: source/library/math/atan2f.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
