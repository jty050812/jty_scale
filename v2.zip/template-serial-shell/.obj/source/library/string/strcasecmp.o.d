.obj/source/library/string/strcasecmp.o: \
 source/library/string/strcasecmp.c include/library/types.h \
 include/library/ctype.h include/library/string.h
include/library/types.h:
include/library/ctype.h:
include/library/string.h:
