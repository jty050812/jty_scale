.obj/source/library/math/sinf.o: source/library/math/sinf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
