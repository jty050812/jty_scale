.obj/source/graphic/pixel.o: source/graphic/pixel.c \
 include/graphic/pixel.h include/library/types.h include/graphic/color.h
include/graphic/pixel.h:
include/library/types.h:
include/graphic/color.h:
