.obj/source/library/ctype/isalpha.o: source/library/ctype/isalpha.c \
 include/library/ctype.h
include/library/ctype.h:
