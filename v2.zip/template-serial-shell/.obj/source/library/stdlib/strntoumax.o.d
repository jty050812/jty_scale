.obj/source/library/stdlib/strntoumax.o: \
 source/library/stdlib/strntoumax.c include/library/stddef.h \
 include/library/ctype.h include/library/stdlib.h include/library/types.h
include/library/stddef.h:
include/library/ctype.h:
include/library/stdlib.h:
include/library/types.h:
