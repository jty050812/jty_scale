.obj/source/graphic/color.o: source/graphic/color.c \
 include/library/types.h include/library/ctype.h include/library/stdlib.h \
 include/library/stddef.h include/library/string.h \
 include/graphic/color.h
include/library/types.h:
include/library/ctype.h:
include/library/stdlib.h:
include/library/stddef.h:
include/library/string.h:
include/graphic/color.h:
