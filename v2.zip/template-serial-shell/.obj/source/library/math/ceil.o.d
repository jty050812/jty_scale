.obj/source/library/math/ceil.o: source/library/math/ceil.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
