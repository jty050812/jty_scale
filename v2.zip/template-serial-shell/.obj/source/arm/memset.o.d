.obj/source/arm/memset.o: source/arm/memset.S
