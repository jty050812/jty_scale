.obj/source/library/math/e_rem_pio2f.o: source/library/math/e_rem_pio2f.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
