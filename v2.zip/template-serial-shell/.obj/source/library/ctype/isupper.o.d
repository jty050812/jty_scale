.obj/source/library/ctype/isupper.o: source/library/ctype/isupper.c \
 include/library/ctype.h
include/library/ctype.h:
