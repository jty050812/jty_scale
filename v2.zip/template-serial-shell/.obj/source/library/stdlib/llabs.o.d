.obj/source/library/stdlib/llabs.o: source/library/stdlib/llabs.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
