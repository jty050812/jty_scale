.obj/source/hardware/hw-led.o: source/hardware/hw-led.c \
 include/library/types.h include/library/io.h \
 include/hardware/s5pv210/reg-gpio.h include/hardware/hw-led.h
include/library/types.h:
include/library/io.h:
include/hardware/s5pv210/reg-gpio.h:
include/hardware/hw-led.h:
