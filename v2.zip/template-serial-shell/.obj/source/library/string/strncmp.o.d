.obj/source/library/string/strncmp.o: source/library/string/strncmp.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
