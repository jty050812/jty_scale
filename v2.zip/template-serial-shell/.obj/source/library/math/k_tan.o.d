.obj/source/library/math/k_tan.o: source/library/math/k_tan.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
