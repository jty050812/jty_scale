.obj/source/library/string/strncat.o: source/library/string/strncat.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
