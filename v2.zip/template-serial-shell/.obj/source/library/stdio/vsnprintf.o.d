.obj/source/library/stdio/vsnprintf.o: source/library/stdio/vsnprintf.c \
 include/library/math.h include/library/types.h include/library/endian.h \
 include/library/stdio.h include/library/ctype.h include/library/errno.h \
 include/library/stdarg.h include/library/stddef.h \
 include/library/stdlib.h include/library/limits.h \
 include/library/string.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
include/library/stdio.h:
include/library/ctype.h:
include/library/errno.h:
include/library/stdarg.h:
include/library/stddef.h:
include/library/stdlib.h:
include/library/limits.h:
include/library/string.h:
