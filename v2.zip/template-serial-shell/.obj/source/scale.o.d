.obj/source/scale.o: source/scale.c include/main.h \
 include/library/types.h include/library/stddef.h \
 include/library/malloc.h include/library/assert.h \
 include/library/sizes.h include/library/string.h \
 include/library/stdlib.h include/library/io.h include/hardware/hw-led.h \
 include/hardware/hw-beep.h include/hardware/hw-key.h \
 include/hardware/hx711.h include/hardware/s5pv210-cp15.h \
 include/hardware/s5pv210-clk.h include/hardware/s5pv210-irq.h \
 include/hardware/s5pv210-tick.h include/hardware/s5pv210-tick-delay.h \
 include/hardware/s5pv210-serial.h \
 include/hardware/s5pv210-serial-stdio.h include/hardware/s5pv210-fb.h \
 include/graphic/surface.h include/graphic/pixel.h \
 include/graphic/color.h include/graphic/maps.h include/graphic/rect.h \
 include/graphic/maps/software.h include/hardware/s5pv210/reg-serial.h \
 include/hardware/s5pv210/reg-gpio.h include/scale.h \
 include/graphic/text.h include/library/readline.h \
 include/library/stdio.h include/library/ctype.h include/library/errno.h \
 include/library/stdarg.h include/library/limits.h
include/main.h:
include/library/types.h:
include/library/stddef.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/string.h:
include/library/stdlib.h:
include/library/io.h:
include/hardware/hw-led.h:
include/hardware/hw-beep.h:
include/hardware/hw-key.h:
include/hardware/hx711.h:
include/hardware/s5pv210-cp15.h:
include/hardware/s5pv210-clk.h:
include/hardware/s5pv210-irq.h:
include/hardware/s5pv210-tick.h:
include/hardware/s5pv210-tick-delay.h:
include/hardware/s5pv210-serial.h:
include/hardware/s5pv210-serial-stdio.h:
include/hardware/s5pv210-fb.h:
include/graphic/surface.h:
include/graphic/pixel.h:
include/graphic/color.h:
include/graphic/maps.h:
include/graphic/rect.h:
include/graphic/maps/software.h:
include/hardware/s5pv210/reg-serial.h:
include/hardware/s5pv210/reg-gpio.h:
include/scale.h:
include/graphic/text.h:
include/library/readline.h:
include/library/stdio.h:
include/library/ctype.h:
include/library/errno.h:
include/library/stdarg.h:
include/library/limits.h:
