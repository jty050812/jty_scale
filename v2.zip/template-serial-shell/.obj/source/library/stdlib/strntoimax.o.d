.obj/source/library/stdlib/strntoimax.o: \
 source/library/stdlib/strntoimax.c include/library/stddef.h \
 include/library/ctype.h include/library/stdlib.h include/library/types.h
include/library/stddef.h:
include/library/ctype.h:
include/library/stdlib.h:
include/library/types.h:
