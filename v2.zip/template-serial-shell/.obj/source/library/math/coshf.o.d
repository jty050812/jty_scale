.obj/source/library/math/coshf.o: source/library/math/coshf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
