.obj/source/library/string/strcat.o: source/library/string/strcat.c \
 include/library/string.h include/library/types.h
include/library/string.h:
include/library/types.h:
