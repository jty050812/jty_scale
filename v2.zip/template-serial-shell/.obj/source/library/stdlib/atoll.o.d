.obj/source/library/stdlib/atoll.o: source/library/stdlib/atoll.c \
 include/library/stddef.h include/library/stdlib.h \
 include/library/types.h
include/library/stddef.h:
include/library/stdlib.h:
include/library/types.h:
