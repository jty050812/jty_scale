.obj/source/library/math/sqrt.o: source/library/math/sqrt.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
