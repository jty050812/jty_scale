.obj/source/library/math/atan.o: source/library/math/atan.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
