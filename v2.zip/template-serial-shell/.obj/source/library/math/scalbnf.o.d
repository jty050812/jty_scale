.obj/source/library/math/scalbnf.o: source/library/math/scalbnf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
