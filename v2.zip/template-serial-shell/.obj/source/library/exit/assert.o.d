.obj/source/library/exit/assert.o: source/library/exit/assert.c \
 include/library/assert.h
include/library/assert.h:
