.obj/source/library/string/strlen.o: source/library/string/strlen.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
