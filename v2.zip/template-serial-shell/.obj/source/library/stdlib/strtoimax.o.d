.obj/source/library/stdlib/strtoimax.o: source/library/stdlib/strtoimax.c \
 include/library/ctype.h include/library/errno.h include/library/limits.h \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/ctype.h:
include/library/errno.h:
include/library/limits.h:
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
