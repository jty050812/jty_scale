.obj/source/library/ctype/isspace.o: source/library/ctype/isspace.c \
 include/library/ctype.h
include/library/ctype.h:
