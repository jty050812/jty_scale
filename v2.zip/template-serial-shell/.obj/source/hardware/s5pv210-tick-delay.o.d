.obj/source/hardware/s5pv210-tick-delay.o: \
 source/hardware/s5pv210-tick-delay.c include/library/types.h \
 include/library/stddef.h include/library/io.h include/library/sizes.h \
 include/library/string.h include/hardware/s5pv210-clk.h \
 include/hardware/s5pv210-irq.h include/hardware/s5pv210-tick.h \
 include/hardware/s5pv210-tick-delay.h
include/library/types.h:
include/library/stddef.h:
include/library/io.h:
include/library/sizes.h:
include/library/string.h:
include/hardware/s5pv210-clk.h:
include/hardware/s5pv210-irq.h:
include/hardware/s5pv210-tick.h:
include/hardware/s5pv210-tick-delay.h:
