.obj/source/hardware/hw-beep.o: source/hardware/hw-beep.c \
 include/library/types.h include/library/io.h \
 include/hardware/s5pv210/reg-gpio.h include/hardware/hw-beep.h
include/library/types.h:
include/library/io.h:
include/hardware/s5pv210/reg-gpio.h:
include/hardware/hw-beep.h:
