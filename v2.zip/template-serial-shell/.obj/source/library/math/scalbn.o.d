.obj/source/library/math/scalbn.o: source/library/math/scalbn.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
