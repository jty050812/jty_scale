.obj/source/library/string/strpbrk.o: source/library/string/strpbrk.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
