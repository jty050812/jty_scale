.obj/source/hardware/s5pv210-fb.o: source/hardware/s5pv210-fb.c \
 include/library/types.h include/library/string.h \
 include/library/stddef.h include/library/malloc.h \
 include/library/assert.h include/library/sizes.h include/library/io.h \
 include/graphic/surface.h include/graphic/pixel.h \
 include/graphic/color.h include/graphic/maps.h include/graphic/rect.h \
 include/graphic/maps/software.h include/hardware/s5pv210/reg-gpio.h \
 include/hardware/s5pv210/reg-others.h include/hardware/s5pv210/reg-lcd.h \
 include/hardware/s5pv210-clk.h include/hardware/s5pv210-tick-delay.h \
 include/hardware/s5pv210-fb.h
include/library/types.h:
include/library/string.h:
include/library/stddef.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/io.h:
include/graphic/surface.h:
include/graphic/pixel.h:
include/graphic/color.h:
include/graphic/maps.h:
include/graphic/rect.h:
include/graphic/maps/software.h:
include/hardware/s5pv210/reg-gpio.h:
include/hardware/s5pv210/reg-others.h:
include/hardware/s5pv210/reg-lcd.h:
include/hardware/s5pv210-clk.h:
include/hardware/s5pv210-tick-delay.h:
include/hardware/s5pv210-fb.h:
