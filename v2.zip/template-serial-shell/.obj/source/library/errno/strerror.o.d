.obj/source/library/errno/strerror.o: source/library/errno/strerror.c \
 include/library/errno.h
include/library/errno.h:
