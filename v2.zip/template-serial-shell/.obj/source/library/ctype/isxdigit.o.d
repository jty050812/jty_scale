.obj/source/library/ctype/isxdigit.o: source/library/ctype/isxdigit.c \
 include/library/ctype.h
include/library/ctype.h:
