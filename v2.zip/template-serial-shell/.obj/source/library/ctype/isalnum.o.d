.obj/source/library/ctype/isalnum.o: source/library/ctype/isalnum.c \
 include/library/ctype.h
include/library/ctype.h:
