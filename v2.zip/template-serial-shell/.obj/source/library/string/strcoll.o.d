.obj/source/library/string/strcoll.o: source/library/string/strcoll.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
