.obj/source/arm/memcpy.o: source/arm/memcpy.S
