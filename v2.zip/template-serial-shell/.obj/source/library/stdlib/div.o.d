.obj/source/library/stdlib/div.o: source/library/stdlib/div.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
