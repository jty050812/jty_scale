.obj/source/library/math/k_cosf.o: source/library/math/k_cosf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
