.obj/source/library/math/tanf.o: source/library/math/tanf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
