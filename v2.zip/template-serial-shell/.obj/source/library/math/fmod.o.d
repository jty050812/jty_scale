.obj/source/library/math/fmod.o: source/library/math/fmod.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
