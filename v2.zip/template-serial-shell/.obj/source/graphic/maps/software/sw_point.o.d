.obj/source/graphic/maps/software/sw_point.o: \
 source/graphic/maps/software/sw_point.c include/graphic/maps/software.h \
 include/library/types.h include/graphic/surface.h \
 include/library/stddef.h include/library/malloc.h \
 include/library/assert.h include/library/sizes.h \
 include/library/string.h include/graphic/pixel.h include/graphic/color.h \
 include/graphic/maps.h include/graphic/rect.h
include/graphic/maps/software.h:
include/library/types.h:
include/graphic/surface.h:
include/library/stddef.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/string.h:
include/graphic/pixel.h:
include/graphic/color.h:
include/graphic/maps.h:
include/graphic/rect.h:
