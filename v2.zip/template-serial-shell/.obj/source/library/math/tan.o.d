.obj/source/library/math/tan.o: source/library/math/tan.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
