.obj/source/library/stdlib/ldiv.o: source/library/stdlib/ldiv.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
