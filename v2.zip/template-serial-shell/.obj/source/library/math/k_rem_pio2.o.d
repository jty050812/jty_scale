.obj/source/library/math/k_rem_pio2.o: source/library/math/k_rem_pio2.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
