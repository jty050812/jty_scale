.obj/source/library/charset.o: source/library/charset.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h include/library/malloc.h \
 include/library/assert.h include/library/sizes.h \
 include/library/charset.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/library/charset.h:
