.obj/source/library/ctype/toascii.o: source/library/ctype/toascii.c \
 include/library/ctype.h
include/library/ctype.h:
