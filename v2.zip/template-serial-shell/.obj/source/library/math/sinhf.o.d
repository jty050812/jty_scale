.obj/source/library/math/sinhf.o: source/library/math/sinhf.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
