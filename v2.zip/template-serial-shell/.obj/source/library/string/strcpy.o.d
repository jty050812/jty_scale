.obj/source/library/string/strcpy.o: source/library/string/strcpy.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
