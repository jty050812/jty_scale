.obj/source/library/math/expm1.o: source/library/math/expm1.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
