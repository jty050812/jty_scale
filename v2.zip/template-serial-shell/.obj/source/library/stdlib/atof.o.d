.obj/source/library/stdlib/atof.o: source/library/stdlib/atof.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
