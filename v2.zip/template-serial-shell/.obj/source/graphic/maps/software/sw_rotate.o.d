.obj/source/graphic/maps/software/sw_rotate.o: \
 source/graphic/maps/software/sw_rotate.c include/library/types.h \
 include/library/string.h include/graphic/maps/software.h \
 include/graphic/surface.h include/library/stddef.h \
 include/library/malloc.h include/library/assert.h \
 include/library/sizes.h include/graphic/pixel.h include/graphic/color.h \
 include/graphic/maps.h include/graphic/rect.h
include/library/types.h:
include/library/string.h:
include/graphic/maps/software.h:
include/graphic/surface.h:
include/library/stddef.h:
include/library/malloc.h:
include/library/assert.h:
include/library/sizes.h:
include/graphic/pixel.h:
include/graphic/color.h:
include/graphic/maps.h:
include/graphic/rect.h:
