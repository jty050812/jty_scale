.obj/source/library/string/strnlen.o: source/library/string/strnlen.c \
 include/library/types.h include/library/string.h
include/library/types.h:
include/library/string.h:
