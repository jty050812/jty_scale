.obj/source/library/math/k_sin.o: source/library/math/k_sin.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
