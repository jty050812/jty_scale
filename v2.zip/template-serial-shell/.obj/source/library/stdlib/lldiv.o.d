.obj/source/library/stdlib/lldiv.o: source/library/stdlib/lldiv.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
