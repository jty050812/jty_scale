.obj/source/hardware/hw-key.o: source/hardware/hw-key.c \
 include/library/types.h include/library/io.h include/library/stddef.h \
 include/hardware/s5pv210/reg-gpio.h include/hardware/hw-key.h
include/library/types.h:
include/library/io.h:
include/library/stddef.h:
include/hardware/s5pv210/reg-gpio.h:
include/hardware/hw-key.h:
