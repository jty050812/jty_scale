.obj/source/library/ctype/iscntrl.o: source/library/ctype/iscntrl.c \
 include/library/ctype.h
include/library/ctype.h:
