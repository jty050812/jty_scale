.obj/source/library/string/strncasecmp.o: \
 source/library/string/strncasecmp.c include/library/types.h \
 include/library/ctype.h include/library/string.h
include/library/types.h:
include/library/ctype.h:
include/library/string.h:
