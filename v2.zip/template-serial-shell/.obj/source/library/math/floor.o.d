.obj/source/library/math/floor.o: source/library/math/floor.c \
 include/library/math.h include/library/types.h include/library/endian.h
include/library/math.h:
include/library/types.h:
include/library/endian.h:
