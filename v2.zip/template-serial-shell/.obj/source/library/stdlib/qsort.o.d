.obj/source/library/stdlib/qsort.o: source/library/stdlib/qsort.c \
 include/library/stdlib.h include/library/types.h \
 include/library/stddef.h
include/library/stdlib.h:
include/library/types.h:
include/library/stddef.h:
