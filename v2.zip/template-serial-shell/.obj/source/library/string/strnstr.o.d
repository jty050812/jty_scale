.obj/source/library/string/strnstr.o: source/library/string/strnstr.c \
 include/library/types.h include/library/stddef.h \
 include/library/string.h
include/library/types.h:
include/library/stddef.h:
include/library/string.h:
